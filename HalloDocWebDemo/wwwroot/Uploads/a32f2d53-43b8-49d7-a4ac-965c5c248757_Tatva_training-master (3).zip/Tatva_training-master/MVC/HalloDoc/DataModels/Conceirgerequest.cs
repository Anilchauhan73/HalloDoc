﻿namespace HalloDoc.DataModels
{
    public class Conceirgerequest
    {
    }
}
