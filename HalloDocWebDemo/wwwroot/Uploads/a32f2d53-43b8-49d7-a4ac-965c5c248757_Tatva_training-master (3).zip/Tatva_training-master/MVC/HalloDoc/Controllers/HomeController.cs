﻿using HalloDoc.DataContext;
using HalloDoc.DataModels;
using HalloDoc.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace HalloDoc.Controllers
{
    public class HomeController : Controller
    {
       
      

        private readonly ApplicationDbContext _context;

    

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Patient_register()
        {
            return View();
        }
        public IActionResult Patient_request()
        {
            return View();
        }

     
         [HttpPost]
        public IActionResult CreatePatientRequest(Patientrequest model)
        {

            AspNetUser aspnetuser = _context.AspNetUsers.FirstOrDefault(u => u.Email == model.Email);


            if (aspnetuser == null)
            {
                AspNetUser aspnetuser1 = new AspNetUser
                {
                    Id = "57",
                    UserName = model.FirstName + "_" + model.LastName,
                    Email = model.Email,
                    PasswordHash = model.FirstName,
                    PhoneNumber = model.PhoneNumber,
                    CreatedDate = DateTime.Now,
                };
                _context.AspNetUsers.Add(aspnetuser1);
                aspnetuser = aspnetuser1;
            }


            User user = new User
            {
             
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Mobile = model.PhoneNumber,
                ZipCode = model.ZipCode,
                State = model.State,
                City = model.City,
                Street = model.Street,
                IntDate = model.BirthDate.Day,
                IntYear = model.BirthDate.Year,
                StrMonth = (model.BirthDate.Month).ToString(),
                CreatedDate = DateTime.Now,
                CreatedBy = "Patient",
                AspNetUser = aspnetuser,
            };

            _context.Users.Add(user);

            Request request = new Request
            {
               
                FirstName = model.FirstName,
                LastName = model.LastName,
                PhoneNumber = model.PhoneNumber,
                Email = model.Email,
                CreatedDate = DateTime.Now,
                Status = 1,
                IsUrgentEmailSent = '1',
                User = user,
            };

            _context.Requests.Add(request);

            RequestWiseFile file = new RequestWiseFile
            {
                FileName = model.Choose_file,
                CreatedDate = DateTime.Now,
            };

            _context.RequestWiseFiles.Add(file);
            _context.SaveChanges();


            return RedirectToAction("Index", "Home");



        }

        //private string RandomString(int v)
        //{
        //    throw new NotImplementedException();
        //}
        public IActionResult Family_request()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateFamilyRequest(Familyrequest model)
        {

            AspNetUser aspnetuser = _context.AspNetUsers.FirstOrDefault(u => u.Email == model.Email);


            if (aspnetuser == null)
            {
                AspNetUser aspnetuser1 = new AspNetUser
                {
            
                    UserName = model.FirstName + "_" + model.LastName,
                    Email = model.Email,
                    PasswordHash = model.FirstName,
                    PhoneNumber = model.PhoneNumber,
                    CreatedDate = DateTime.Now,
                };
                _context.AspNetUsers.Add(aspnetuser1);
                aspnetuser = aspnetuser1;
            }


            User user = new User
            {
            
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Mobile = model.PhoneNumber,
                ZipCode = model.ZipCode,
                State = model.State,
                City = model.City,
                Street = model.Street,
                IntDate = model.BirthDate.Day,
                IntYear = model.BirthDate.Year,
                StrMonth = (model.BirthDate.Month).ToString(),
                CreatedDate = DateTime.Now,
                CreatedBy = "Family",
                AspNetUser = aspnetuser,
            };

            _context.Users.Add(user);

            RequestClient requestfamily = new RequestClient
            {
             
                RequestId = 54645,
                FirstName = model.YourFirstName,
                LastName = model.YourLastName,
                PhoneNumber = model.YourPhoneNumber,
                Email = model.YourEmail,
                State=model.RelationWithPatient,

            };

            _context.RequestClients.Add(requestfamily);

            Request request = new Request
            {
               
                FirstName = model.FirstName,
                LastName = model.LastName,
                PhoneNumber = model.PhoneNumber,
                Email = model.Email,
                CreatedDate = DateTime.Now,
                Status = 1,
                IsUrgentEmailSent = '1',
                User = user,
            };

            _context.Requests.Add(request);
            _context.SaveChanges();


            return RedirectToAction("Index", "Home");



        }

        public IActionResult Conceirge_request()
        {
            return View();
        }


        [HttpPost]
        public IActionResult CreateConceirgeRequest (Conceirgerequest1 model)
        {

            AspNetUser aspnetuser = _context.AspNetUsers.FirstOrDefault(u=> u.Email == model.Email);

            

            User user = new User
            {

                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Mobile = model.PhoneNumber,
                CreatedDate = DateTime.Now,
                CreatedBy = "Conceirge",
                
            };

            _context.Users.Add(user);

            Concierge concierge = new Concierge
            {
                ConciergeName = model.YourFirstName,
                Street = model.YourStreet,
                City = model.YourCity,
                State = model.YourState,
                ZipCode = model.YourZipCode,
                CreatedDate = DateTime.Now,
            };

              _context.Concierges.Add(concierge);

            RequestClient requestconceirge = new RequestClient
            {
                FirstName = model.YourFirstName,
                LastName = model.YourLastName,
                PhoneNumber = model.YourPhoneNumber,
                Email = model.YourEmail,

            };

            _context.RequestClients.Add(requestconceirge);

            Request request = new Request
            {

                FirstName = model.YourFirstName,
                LastName = model.YourLastName,
                PhoneNumber = model.YourPhoneNumber,
                Email = model.YourEmail,
                CreatedDate = DateTime.Now,
                Status = 1,
                IsUrgentEmailSent = '1',
                User = user,
            };

            _context.Requests.Add(request);
             _context.SaveChanges();



            return RedirectToAction("Index", "Home");

        }



        public IActionResult Business_request()
        {
            return View();
        }
        public IActionResult Patient_login()
        {
            return View();
        }
        public IActionResult Forget_pass()
        {
            return View();
        }

        public IActionResult Reset_password()
        {
            return View();
        }



        public IActionResult PatientDashboard()
        {
            var userEmail = HttpContext.Session.GetString("userEmail");
            if (userEmail == null)
            {
                return RedirectToAction("Patient_login");

            }
            List<Request> userData = _context.Requests.Where(u => u.Email == userEmail).ToList();

            return View(userData);
        }

        //public async Task<IActionResult> EditPatientInformation(string AspNetUserId)
        //{
        //    if (AspNetUserId == null || _context.Users == null)
        //    {
        //        return NotFound();
        //    }

        //    var user = await _context.Users.FindAsync(AspNetUserId);
        //    if (user == null)
        //    {
        //        return NotFound();
        //    }
        //    return View(user);
        //}

        //// POST: AspNetUsers/Edit/5
        //// To protect from overposting attacks, enable the specific properties you want to bind to.
        //// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> EditPatientInformation(string Id, [Bind("AspNetUserId,UserId,FirstName,LastName,Email,Mobile,IsMobile,Street,City,State,RegionId,ZipCode,StrMonth,IntYear,IntDate,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate,IsDeleted,Ip,IsRequestWithEmail")] User user)
        //{
        //    if (Id != user.AspNetUserId)
        //    {
        //        return NotFound();
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            _context.Update(user);
        //            await _context.SaveChangesAsync();
        //        }
        //        catch (DbUpdateConcurrencyException)
        //        {
        //            if (!AspNetUserExists(Convert.ToInt32(user.AspNetUserId)))
        //            {
        //                return NotFound();
        //            }
        //            else
        //            {
        //                throw;
        //            }
        //        }
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(user);
        //}

        //private bool AspNetUserExists(int v)
        //{
        //    throw new NotImplementedException();
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}