
/*SELECT first_name , last_name , a.address_id ,address , district , phone 
FROM customer c
INNER JOIN address a
ON c.address_id = a.address_id
WHERE district = 'Texas'; */

/*SELECT f.film_id , f.title , i.inventory_id , i.store_id
FROM film f 
LEFT JOIN inventory i 
ON f.film_id = i.film_id 
WHERE inventory_id is NULL; */


/*SELECT s.address_id , s.last_name ,  a.address_id , a.district
FROM staff s
RIGHT JOIN address a 
ON s.address_id = a.address_id; */

/* SELECT c.address_id , c.last_name ,  a.address_id , a.district
FROM customer c
Full JOIN address a 
ON c.address_id = a.address_id; */

/*SELECT name from category 
UNION 
SELECT name from language; */

/*SELECT f.title , f.rental_rate , l.name
From film f 
INNER JOIN language l
ON f.language_id = l.language_id ; */

/* SELECT CONCAT(a.first_name ,' ', a.last_name ) AS "Actor Name", COUNT(f.film_id) AS "Movie Acted "
fROM film_actor f
join actor a 
ON a.actor_id = f.actor_id 
join film fm 
ON fm.film_id = f.film_id 
Group BY   a.first_name , a.last_name
ORDER BY  "Movie Acted " desc; */

SELECT * FROM film
select * from rental
select * from inventory

SELECT f.rating ,COUNT(i.inventory_id)  From inventory i 
RIGHT JOIN film f 
ON i.film_id = f.film_id
Right Join rental r 
ON r.inventory_id = i.inventory_id
GROUP BY f.rating;




