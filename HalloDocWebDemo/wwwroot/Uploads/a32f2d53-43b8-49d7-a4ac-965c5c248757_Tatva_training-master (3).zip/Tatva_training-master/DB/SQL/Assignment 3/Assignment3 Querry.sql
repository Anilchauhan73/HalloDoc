
--- QUERRY NO.1 ----

--SELECT d.dept_name ,Max(salary) AS Maximum_salary
--FROM Department d 
--INNER JOIN Employee e 
--ON e.dept_id=d.dept_id
--GROUP BY d.dept_name




-- QUERRY NO.2----

--SELECT d.dept_name,COUNT(emp_id) 
--FROM Department d 
--INNER JOIN Employee e 
--ON e.dept_id=d.dept_id
--GROUP BY d.dept_name
--HAVING COUNT(emp_id) <3



-- querry no 3 ---
--SELECT d.dept_name,COUNT(emp_id) 
--FROM Department d 
--INNER JOIN Employee e 
--ON e.dept_id=d.dept_id
--GROUP BY d.dept_name


---Querry no.4---
SELECT d.dept_name,SUM(Salary) AS Total_salary
FROM Department d 
INNER JOIN Employee e 
ON e.dept_id=d.dept_id
GROUP BY d.dept_name


