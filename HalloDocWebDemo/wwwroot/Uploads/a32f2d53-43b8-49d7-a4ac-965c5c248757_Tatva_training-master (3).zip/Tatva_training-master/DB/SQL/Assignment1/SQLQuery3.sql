Select product_id,product_name,unit_price From products
Where unit_price > (SELECT AVG(unit_price) From products);
GO
