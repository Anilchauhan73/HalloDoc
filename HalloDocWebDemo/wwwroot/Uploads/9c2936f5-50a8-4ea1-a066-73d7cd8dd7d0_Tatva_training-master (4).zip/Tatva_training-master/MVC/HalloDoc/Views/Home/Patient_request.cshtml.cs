using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HalloDoc.Views.Home
{
    public class Patient_requestModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
