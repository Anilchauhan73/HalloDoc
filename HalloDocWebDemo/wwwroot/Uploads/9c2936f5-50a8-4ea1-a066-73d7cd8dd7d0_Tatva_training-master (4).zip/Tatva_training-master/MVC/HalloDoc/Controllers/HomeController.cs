﻿using HalloDoc.DataContext;
using HalloDoc.DataModels;
using HalloDoc.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.IO.Compression;
using System.Linq;


namespace HalloDoc.Controllers
{
    public class HomeController : Controller
    {
       


        private readonly ApplicationDbContext _context;


        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment hostingEnvironment;
        private int id;

        public HomeController(ApplicationDbContext context , Microsoft.AspNetCore.Hosting.IHostingEnvironment hostingEnvironment)
        {
            _context = context;
         
            this.hostingEnvironment = hostingEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Patient_register()
        {
            return View();
        }
        public IActionResult Patient_request()
        {
            return View();
        }

     
         [HttpPost]
        public IActionResult CreatePatientRequest(Patientrequest model)
        {

            AspNetUser aspnetuser = _context.AspNetUsers.FirstOrDefault(u => u.Email == model.Email);


            if (aspnetuser == null)
            {
                AspNetUser aspnetuser1 = new AspNetUser
                {
                    Id = "1234",
                    UserName = model.FirstName + "_" + model.LastName,
                    Email = model.Email,
                    PasswordHash = model.FirstName,
                    PhoneNumber = model.PhoneNumber,
                    CreatedDate = DateTime.Now,
                };
                _context.AspNetUsers.Add(aspnetuser1);
                aspnetuser = aspnetuser1;
            }


            User user = new User
            {
             
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Mobile = model.PhoneNumber,
                ZipCode = model.ZipCode,

                State = model.State,
                City = model.City,
                Street = model.Street,
                IntDate = model.BirthDate.Day,
                IntYear = model.BirthDate.Year,
                StrMonth = (model.BirthDate.Month).ToString(),
                CreatedDate = DateTime.Now,
                CreatedBy = "Patient",
                AspNetUser = aspnetuser,
            };

            _context.Users.Add(user);

            Request request = new Request
            {
               
                FirstName = model.FirstName,
                LastName = model.LastName,
                PhoneNumber = model.PhoneNumber,
                Email = model.Email,
                CreatedDate = DateTime.Now,
                Status = 1,
                IsUrgentEmailSent = '1',
                User = user,
            };

            _context.Requests.Add(request);
            _context.SaveChanges();

            foreach (var item in model.File)
            {

                var file = item.FileName;
                String uniqueFilename = null;
                if (model.File != null)
                {

                    String uploadFolder = Path.Combine(hostingEnvironment.WebRootPath, "Uploads");
                    uniqueFilename = Guid.NewGuid().ToString() + "_" + file;
                    String FilePath = Path.Combine(uploadFolder, uniqueFilename);
                    item.CopyTo(new FileStream(FilePath, FileMode.Create));

                }
                RequestWiseFile requestWiseFile = new RequestWiseFile
                {
                    RequestId = request.RequestId,
                    FileName = uniqueFilename,
                    Request = request,
                    CreatedDate = DateTime.Now
                };
                _context.RequestWiseFiles.Add(requestWiseFile);
                _context.SaveChanges();


            }


            return RedirectToAction("Index", "Home");
        



        }
        public IActionResult Family_request()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateFamilyRequest(Familyrequest model)
        {

            AspNetUser aspnetuser = _context.AspNetUsers.FirstOrDefault(u => u.Email == model.Email);


            if (aspnetuser == null)
            {
                AspNetUser aspnetuser1 = new AspNetUser
                {
            
                    UserName = model.FirstName + "_" + model.LastName,
                    Email = model.Email,
                    PasswordHash = model.FirstName,
                    PhoneNumber = model.PhoneNumber,
                    CreatedDate = DateTime.Now,
                };
                _context.AspNetUsers.Add(aspnetuser1);
                aspnetuser = aspnetuser1;
            }


            User user = new User
            {
            
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Mobile = model.PhoneNumber,
                ZipCode = model.ZipCode,
                State = model.State,
                City = model.City,
                Street = model.Street,
                IntDate = model.BirthDate.Day,
                IntYear = model.BirthDate.Year,
                StrMonth = (model.BirthDate.Month).ToString(),
                CreatedDate = DateTime.Now,
                CreatedBy = "Family",
                AspNetUser = aspnetuser,
            };

            _context.Users.Add(user);

            RequestClient requestfamily = new RequestClient
            {
             
                RequestId = 54645,
                FirstName = model.YourFirstName,
                LastName = model.YourLastName,
                PhoneNumber = model.YourPhoneNumber,
                Email = model.YourEmail,
                State=model.RelationWithPatient,

            };

            _context.RequestClients.Add(requestfamily);

            Request request = new Request
            {
               
                FirstName = model.FirstName,
                LastName = model.LastName,
                PhoneNumber = model.PhoneNumber,
                Email = model.Email,
                CreatedDate = DateTime.Now,
                Status = 1,
                IsUrgentEmailSent = '1',
                User = user,
            };

            _context.Requests.Add(request);
            _context.SaveChanges();


            String uniqueFilename1 = null;
            if (model.File != null)
            {

                String uploadFolder = Path.Combine(hostingEnvironment.WebRootPath, "Uploads");
                uniqueFilename1 = Guid.NewGuid().ToString() + "_" + model.File.FileName;
                //uniqueFilename = model.File.FileName;
                String FilePath = Path.Combine(uploadFolder, uniqueFilename1);
                model.File.CopyTo(new FileStream(FilePath, FileMode.Create));

            }
            RequestWiseFile requestWiseFile = new RequestWiseFile
            {
                RequestId = request.RequestId,
                FileName = uniqueFilename1,
                Request = request,
                CreatedDate = DateTime.Now
            };
            _context.RequestWiseFiles.Add(requestWiseFile);
            _context.SaveChanges();




            return RedirectToAction("Index", "Home");



        }

        public IActionResult Conceirge_request()
        {
            return View();
        }


        [HttpPost]
        public IActionResult CreateConceirgeRequest (Conceirgerequest1 model)
        {

            AspNetUser aspnetuser = _context.AspNetUsers.FirstOrDefault(u=> u.Email == model.Email);

            

            User user = new User
            {

                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Mobile = model.PhoneNumber,
                CreatedDate = DateTime.Now,
                CreatedBy = "Conceirge",
                
            };

            _context.Users.Add(user);

            Concierge concierge = new Concierge
            {
                ConciergeName = model.YourFirstName,
                Street = model.YourStreet,
                City = model.YourCity,
                State = model.YourState,
                ZipCode = model.YourZipCode,
                CreatedDate = DateTime.Now,
            };

              _context.Concierges.Add(concierge);

            RequestClient requestconceirge = new RequestClient
            {
                FirstName = model.YourFirstName,
                LastName = model.YourLastName,
                PhoneNumber = model.YourPhoneNumber,
                Email = model.YourEmail,

            };

            _context.RequestClients.Add(requestconceirge);

            Request request = new Request
            {

                FirstName = model.YourFirstName,
                LastName = model.YourLastName,
                PhoneNumber = model.YourPhoneNumber,
                Email = model.YourEmail,
                CreatedDate = DateTime.Now,
                Status = 1,
                IsUrgentEmailSent = '1',
                User = user,
            };

            _context.Requests.Add(request);
             _context.SaveChanges();



            return RedirectToAction("Index", "Home");

        }



        public IActionResult Business_request()
        {
            return View();
        }
        public IActionResult Patient_login()
        {
            return View();
        }
        public IActionResult Forget_pass()
        {
            return View();
        }

        public IActionResult Reset_password()
        {
            return View();
        }



        public IActionResult PatientDashboard(PatientDashboard details)
        {
            var userEmail = HttpContext.Session.GetString("userEmail");
            if (userEmail == null)
            {
                return RedirectToAction("Patient_login");

            }
            List<Request> userData = _context.Requests.Where(u => u.Email == userEmail).ToList();
            PatientDashboard dashboard = new PatientDashboard();
            dashboard.Request = userData;
            ViewBag.document = _context.RequestWiseFiles.ToList();
            details.Request = userData;


            return View(dashboard);
        }


        //public IActionResult Download(int documentid)
        //{
        //    var filename = _context.RequestWiseFiles.FirstOrDefault(u => u.RequestWiseFileId == documentid);
        //    var filepath = Path.Combine(hostingEnvironment.WebRootPath, "Uploads", filename.FileName);
            
        //    return File(System.IO.File.ReadAllBytes(filepath), "multipart/form-data", System.IO.Path.GetFileName(filepath));

        //}

        public IActionResult DownLoadAll(int requestid)
        {

            var zipName = $"TestFiles-{DateTime.Now.ToString("yyyy_MM_dd-HH_mm_ss")}.zip";

            using (MemoryStream ms = new MemoryStream())
            {
                //required: using System.IO.Compression;  
                using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
                {
                    //QUery the Products table and get all image content  
                    _context.RequestWiseFiles.Where(u => u.RequestId == requestid).ToList().ForEach(file =>
                    {
                        byte[] fileContent = null;


                        var filepath = Path.Combine(hostingEnvironment.WebRootPath, "Uploads", file.FileName);

                        var entry = zip.CreateEntry(file.FileName);

                        using (FileStream fileone = new FileStream(filepath, FileMode.Open, FileAccess.Read))
                        using (var entryStream = entry.Open())
                        {
                            fileone.CopyTo(entryStream);
                        }
                    });
                }
                return File(ms.ToArray(), "application/zip", zipName);
            }
        }

        public IActionResult ViewDocument()
        {
            return View();
        }


        [HttpGet]
        public IActionResult ViewDocument(int id )
        {
            var data = _context.RequestWiseFiles.Where(u=>u.RequestId == id).ToList();
            ViewBag.data = data;

            var request = _context.Requests.FirstOrDefault(u => u.RequestId == id);
            ViewBag.uploader = request!.FirstName;


            return View();


        }


        public IActionResult PatientProfile()
        {
            var user = _context.Users.FirstOrDefault();
            ViewBag.fname = user!.FirstName;
            ViewBag.lname = user!.LastName;
            ViewBag.street = user!.Street;
            ViewBag.state = user!.State;
            ViewBag.city = user!.City;
            var date = new DateTime(user.IntYear ?? 2024, Convert.ToInt32(user.StrMonth ?? "2"), user.IntDate ?? 1);
            DateOnly dateOnly = DateOnly.FromDateTime(date);
            ViewBag.dob = dateOnly;
            ViewBag.email = user!.Email;
            ViewBag.pnumber = user!.Mobile;
            ViewBag.zipcode = user!.ZipCode;
            return View(user);

        }

        public IActionResult Profile(PatientProfile model)
        {


            var user = HttpContext.Session.GetInt32("userid");
            var aspuser = HttpContext.Session.GetString("aspuserid");
            var userone = _context.Users.FirstOrDefault(u => u.UserId == user);
            var aspuserone = _context.AspNetUsers.FirstOrDefault(u => u.Id == aspuser);
            if (userone != null)
            {
                userone.FirstName = model.FirstName;
                userone.LastName = model.LastName;
                userone.Email = model.Email;
                userone.Street = model.Street;
                userone.City = model.City;
                userone.State = model.State;
                userone.ZipCode = Convert.ToString(model.ZipCode);
                userone.Mobile = Convert.ToString(model.PhoneNumber);

            }
            if (aspuserone != null)
            {
                aspuserone.UserName = model.FirstName + " " + model.LastName;
            }

            _context.SaveChanges();
            return RedirectToAction("PatientDashboard");
        }


        //public ActionResult AddNewUser(User user)
        //{
        //    _commonRepository.Insert(user);
        //    var result = _commonRepository.SaveChanges();
        //    _emailSender.SendEmail(user.Email, "User Regitered");
        //    if (result > 0)
        //    {
        //        return CreatedAtAction("GetUser", new { id = user.id }, user);
        //    }
        //    return BadRequest();


            public IActionResult Privacy()
                {
                    return View();
                }


        public IActionResult ReviewAgreement()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}