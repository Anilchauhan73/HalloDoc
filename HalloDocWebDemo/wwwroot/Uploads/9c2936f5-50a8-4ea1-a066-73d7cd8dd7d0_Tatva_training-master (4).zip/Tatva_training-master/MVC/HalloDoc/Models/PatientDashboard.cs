﻿using HalloDoc.DataModels;
using Microsoft.EntityFrameworkCore.Metadata.Internal;



namespace HalloDoc.Models
{
    public class PatientDashboard
    {
  

        public List<Request> Request { get; set; }

        public List<RequestWiseFile> RequestWiseFile { get; set; }

       


     

    }

}
