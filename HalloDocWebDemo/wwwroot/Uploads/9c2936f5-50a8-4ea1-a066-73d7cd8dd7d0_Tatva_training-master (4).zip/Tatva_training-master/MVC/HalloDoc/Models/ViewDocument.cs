﻿using HalloDoc.DataModels;

namespace HalloDoc.Models
{
    public class ViewDocument
    {


        public List<Request>? Request { get; set; }

        public List<RequestWiseFile>? RequestWiseFiles { get; set; }

    }
}
