

--Querry No.1---

--SELECT S.NAME,S.CITY,C.CUST_NAME
--FROM SALESMAN S
--INNER JOIN CUSTOMER C
--ON S.salesman_id=C.salesman_id
--where s.city= c.city;
--Go


--Querry No.2--
--SELECT O.ORD_NO,O.PUR_AMT,C.CUST_NAME,C.CITY
--FROM order1 o
--left outer join customer c
--on o.customer_id =c.customer_id
--where pur_amt BETWEEN 500 AND 2000;
--GO


--Querry no.3---
SELECT C.CUST_NAME,C.CITY,S.SALESMAN_ID,S.COMMISSION
FROM SALESMAN S
INNER JOIN CUSTOMER C
ON S.SALESMAN_ID=C.SALESMAN_ID
--GO


--- querry no 4 -----
--SELECT C.CUST_NAME , C.CITY , S.NAME , S.COMMISSION
--FROM SALESMAN S 
--LEFT JOIN CUSTOMER C 
--ON S.SALESMAN_ID = C.SALESMAN_ID
--WHERE  S.commission > 0.12;
----GO


-- Querry no -5 --
--SELECT C.CUST_NAME,C.CITY,S.NAME, S.COMMISSION
--FROM SALESMAN S
--LEFT JOIN CUSTOMER C
--ON S.SALESMAN_ID = C.SALESMAN_ID
--WHERE S.CITY != C.CITY AND S.COMMISSION > 0.12
--GO


--- QUERRY NO-6----
--SELECT o.ord_no , o.ord_date , o.pur_amt , c.cust_name , c.grade , s.name , s.commission
--FROM salesman s 
--FULL OUTER JOIN customer c
--ON s.salesman_id = c.salesman_id
--FULL OUTER JOIN order1 o 
--ON s.salesman_id = o.salesman_id;
--go

--  QUERRY NO -7 ---
SELECT s.salesman_id ,s.name ,s.city ,s.commission ,c.customer_id  ,c.cust_name , c.grade , o.ord_no , o.pur_amt , o.ord_date
FROM salesman s 
FULL OUTER JOIN customer c
ON s.salesman_id = c.salesman_id
FULL OUTER JOIN order1 o 
ON s.salesman_id = o.salesman_id;
--go


-- QUERRY NO-8 ---
--select c.cust_name , c.city , c.grade , s.name , s.city 
--from customer c
--inner join salesman s 
--on c.salesman_id = s.salesman_id 
--ORDER BY c.customer_id ASC;



--- QUERRY NO 9 ----

--SELECT c.cust_name , c.city , c.grade , s.name , s.city
--FROM customer c 
--INNER JOIN salesman s 
--ON c.salesman_id = s.salesman_id
--WHERE c.grade <300
--ORDER BY c.customer_id asc;


-- Querry no 10 ---
--select c.cust_name , c.city , o.ord_no , o.ord_date , o.pur_amt
--from customer c 
--left join order1 o 
--on c.customer_id = o.customer_id
--order by o.ord_date

--Querry No 11 --

--select c.cust_name , c.city , o.ord_no , o.ord_date , o.pur_amt , s.name , s.commission
--from customer C
--LEFT OUTER JOIN order1 o
--ON c.customer_id = o.customer_id
--LEFT OUTER JOIN salesman s 
--ON c.salesman_id = s.salesman_id 


-- QUERRY NO 12 ---


--select c.customer_id , c.cust_name ,c.city , c.grade , s.name ,s.commission 
--from customer c
--RIGHT  JOIN salesman s
--ON s.salesman_id = c.salesman_id
--ORDER BY s.salesman_id ;


--QUERRY NO 13---
--SELECT C.CUST_NAME , C.CITY , C.GRADE , O.ORD_NO , O.ORD_DATE , O.PUR_AMT
--FROM  ORDER1 O 
--LEFT OUTER JOIN SALESMAN  S ON S.SALESMAN_ID = O.SALESMAN_ID
--LEFT OUTER JOIN CUSTOMER C ON C.CUSTOMER_ID = O.CUSTOMER_ID;


-- QUERRY NO 14 ----

--SELECT C.cust_name, C.city, c.grade, s.name , o.ord_no, o.ord_date, o.pur_amt 
--FROM customer c
--RIGHT OUTER JOIN salesman s 
--ON s.salesman_id = c.salesman_id 
--LEFT OUTER JOIN order1 o 
--ON c.customer_id = o.customer_id 
--WHERE o.pur_amt >= 2000 
--AND c.grade IS NOT NULL;


---QUERRY NO 15 ----


--SELECT c.cust_name, c.city, c.grade, s.name , o.ord_no, o.ord_date, o.pur_amt 
--FROM customer c
--RIGHT OUTER JOIN salesman s 
--ON s.salesman_id = c.salesman_id 
--LEFT OUTER JOIN order1 o 
--ON c.customer_id = o.customer_id 
--WHERE o.pur_amt >= 2000 
--AND c.grade IS NOT NULL ;


-- QUERRY NO 16 ----

--SELECT C.CUST_NAME , C.CITY ,  O.ORD_NO , O.ORD_DATE , O.PUR_AMT
--FROM CUSTOMER C 
--FULL OUTER JOIN ORDER1 O 
--ON C.CUSTOMER_ID = O.CUSTOMER_ID 
--WHERE C.GRADE IS NOT NULL;


-- QUERRY NO 17 ----
--SELECT * 
--FROM SALESMAN S
--CROSS JOIN CUSTOMER C

--- QUERRY NO 18---
--SELECT * 
--FROM SALESMAN S 
--CROSS JOIN CUSTOMER C
--WHERE S.CITY IS NOT NULL;

--- QUERRY NO 19 ---
--SELECT * 
--FROM SALESMAN S 
--CROSS JOIN CUSTOMER C
--WHERE S.CITY IS NOT NULL AND C.GRADE IS NOT NULL;

-- QUERRY NO 20 ----
SELECT * 
FROM SALESMAN S 
CROSS JOIN CUSTOMER C
WHERE S.CITY != C.CITY AND C.GRADE IS NOT NULL;










