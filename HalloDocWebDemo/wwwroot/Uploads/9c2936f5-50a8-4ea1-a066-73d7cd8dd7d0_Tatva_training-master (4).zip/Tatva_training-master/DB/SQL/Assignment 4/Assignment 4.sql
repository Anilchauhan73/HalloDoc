----Querryy 1 -----

Create procedure calculateavgfreight

@customerid nvarchar(5)

AS
BEGIN

    DECLARE @avgfreight money;

	select @avgfreight = AVG(freight) from orders where customerid = @customerid;
	select @customerid as "customerid", @avgfreight as "average freight" from orders where customerid = @customerid;

	end
	go


create trigger checkfreighttrigger
on orders
after insert, update

AS
BEGIN
     DECLARE @Avgfreight money;
	  DECLARE @customerid nchar(5);
	   DECLARE @freight money;

	   select @customerid = customerid , @freight = freight
	   from inserted;

	   select @avgfreight = AVG(freight) from orders;

	   if @freight > @avgfreight

	   BEGIN
	       RAISERROR ('FREIGHT CANNOT EXCEED THE AVERAGE FREIGHT FOR THE SPECIFIED CUSTOMER.',16,1);
		   ROLLBACK;
		   END
		   END;
		   GO


  exec  calculateavgfreight @customerid = Hanar;
  Select * from orders;


---Querry no.2 ----

--CREATE PROCEDURE salesByCountry

--	@EmpID INT
--AS
--BEGIN
	

--	SELECT o.ShipCountry, SUM(d.OrderAmt) AS Sales
--	 FROM Orders o
--	INNER JOIN (SELECT OrderID, SUM(UnitPrice*Quantity) AS OrderAmt FROM [dbo].[Order Details] GROUP BY OrderID) d 
--	ON o.OrderID = d.OrderID
--	GROUP BY o.EmployeeID, o.ShipCountry
--	HAVING o.EmployeeID = @EmpID ORDER BY o.EmployeeID;

   
	
--END
--GO 
 
 

 --EXEC SalesByCountry @EmpID = 1;


 --- QUERRY NO.3 ---

-- CREATE PROCEDURE SalesByYear

--AS
--BEGIN
	
--	SELECT YEAR(o.OrderDate) AS OrderYear, SUM(d.OrderAmt) AS Sales 
--	FROM Orders o
--	INNER JOIN (SELECT OrderID, SUM(UnitPrice*Quantity) AS OrderAmt FROM [dbo].[Order Details] GROUP BY OrderID) d
--	 ON o.OrderID = d.OrderID
--	GROUP BY  YEAR(o.OrderDate);
 
--END
--GO

--EXEC SalesByYear;

---Querry No 4 ----
--CREATE PROCEDURE SalesByCategory

--AS
--BEGIN
	
--SELECT c.categoryID , c.categoryName , SUM(d.OrderAmt) AS Sales 
--FROM  Products p
--INNER JOIN (SELECT OrderID,ProductId , SUM(UnitPrice*Quantity) AS OrderAmt FROM [dbo].[Order Details] GROUP BY OrderID , ProductID) d
-- ON p.ProductID = d.ProductID
-- INNER JOIN categories c
-- ON p.CategoryId = c.CategoryId
--GROUP BY  c.categoryID,  c.categoryName;
 
--END
--GO

--EXEC SalesByCategory;


--- Querry no.5----
 --CREATE PROCEDURE MostExpensiveProduct

 --AS

 --SELECT TOP 10 PRODUCTNAME , UNITPRICE
 --FROM [PRODUCTS] 
 --ORDER BY UNITPRICE DESC
 --go

 --Exec MostExpensiveProduct


 --- Querry no.6 ----


--Create PROCEDURE InsertDetails (
 
--@OrderId int ,
--@ProductID int ,
--@UnitPrice money ,
--@Quantity smallint ,
--@Discount real )

--AS
--BEGIN

--Insert into [dbo].[Order Details] (OrderId , ProductId , UnitPrice , Quantity , Discount) values (@orderId , @ProductId , @UnitPrice , @Quantity , @Discount )

--END 
--GO


--EXEC InsertDetails @OrderId = 10 , @ProductId = 20, @UnitPrice = 1000 , @Quantity = 53 , @Discount=0;


--select * from [dbo].[Order Details]



---Querry no.7 ---

--Create PROCEDURE UpdateDetails (
 
--@OrderId int ,
--@ProductID int ,
--@UnitPrice money ,
--@Quantity smallint ,
--@Discount real )

--AS
--BEGIN

--Update [dbo].[Order Details] 
-- SET  OrderId= @orderId ,ProductId= @ProductId , UnitPrice = @UnitPrice , Quantity=  @Quantity , Discount = @Discount 
--Where OrderId = @OrderId ;

--END 
--GO

--EXEC UpdateDetails   @OrderId=10 , @ProductId = 23 , @UnitPrice =500 , @Quantity = 5 , @Discount = 3;

select * from [dbo].[Order Details]


                                         