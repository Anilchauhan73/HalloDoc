Select product_id,product_name,unit_price 
From products
Where unit_price <=20 AND  discontinued=0;
GO