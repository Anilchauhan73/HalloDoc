'use strict';



function toggle_visibility() 
{

    
    var e = document.getElementById('anil');
    console.log(e.style.display)
    if (e.style.display == 'flex' || e.style.display=='')
    {
        e.style.display = 'none';
    }
    else 
    {
        e.style.display = 'flex';
    }
}

