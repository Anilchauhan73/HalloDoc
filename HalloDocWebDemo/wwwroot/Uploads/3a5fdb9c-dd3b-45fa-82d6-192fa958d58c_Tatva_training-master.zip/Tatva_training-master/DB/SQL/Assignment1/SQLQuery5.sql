SELECT COUNT(discontinued)
FROM products
where discontinued=1 ;
GO


SELECT COUNT(discontinued)
FROM products
where discontinued=0;
GO 

