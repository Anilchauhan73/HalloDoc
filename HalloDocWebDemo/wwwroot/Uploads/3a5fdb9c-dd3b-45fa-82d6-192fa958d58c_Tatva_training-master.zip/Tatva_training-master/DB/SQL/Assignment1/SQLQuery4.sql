SELECT Top 10 PRODUCT_NAME,unit_price 
FROM products
  ORDER BY unit_price DESC;